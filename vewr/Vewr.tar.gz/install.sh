set -e

mv vewr.o /usr/local/bin/vewr
