cc Vewr.c -o vewr.o \
	-s -Ofast -march=native -flto -DNDEBUG \
	-lm -std=c99 -pedantic -Wall -Wextra -Wsign-compare \
	-Wstrict-aliasing -Wdouble-promotion -fno-signed-zeros -fno-trapping-math \
	-Wno-unused-parameter -Wno-missing-field-initializers \
	-Wno-unused-variable -Wno-unused-result \
	-lX11 -lImlib2
